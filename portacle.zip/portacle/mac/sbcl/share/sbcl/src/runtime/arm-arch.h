#ifndef _ARM_ARCH_H
#define _ARM_ARCH_H

#define ARCH_HAS_LINK_REGISTER

#endif /* _ARM_ARCH_H */
