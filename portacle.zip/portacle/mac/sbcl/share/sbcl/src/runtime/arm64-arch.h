#ifndef _ARM64_ARCH_H
#define _ARM64_ARCH_H

#define ARCH_HAS_LINK_REGISTER

#endif /* _ARM64_ARCH_H */
