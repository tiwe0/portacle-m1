#ifndef _SPARC_ARCH_H
#define _SPARC_ARCH_H

#define ARCH_HAS_NPC_REGISTER

#endif /* _SPARC_ARCH_H */
