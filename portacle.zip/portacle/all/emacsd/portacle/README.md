## About Portacle-Config
This is the collection of elisp files that configure the [Portacle](https://github.com/Shinmera/portacle) Emacs instance.
