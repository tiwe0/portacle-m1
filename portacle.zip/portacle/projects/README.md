## Place your project folders here
This directory is intended to store your own projects. Anything you place in it should be automatically picked up by Quicklisp, and should thus be loadable through `ql:quickload`.
